#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("ggpubr")
#install.packages("reshape2")
#install.packages("cowplot")
#install.packages("patchwork")

options(stringsAsFactors=F)
library(grid)
library(cowplot)
library(patchwork)
library(limma)
library(ggpubr)
library(reshape2)
setwd("D:\\108geneTMB\\18.boxplot")                             
tmb=read.table("TMB.txt",sep="\t",header=T,check.names=F,row.names=1)               
mut=read.table("TCGA.mutMatrix.txt",sep="\t",header=T,check.names=F,row.names=1)    

geneRT=read.table("intersectGenes.txt",sep="\t",header=F,check.names=F)
gene=as.vector(geneRT[,1])
mut=t(mut[gene,])

tmb=tmb[,c(1,1)]
samSample=intersect(row.names(tmb),row.names(mut))
tmb=tmb[samSample,]
mut=mut[samSample,]
rt=cbind(tmb,mut)
rt=rt[,-2]
data=melt(rt,id.vars=c("TMB"))
colnames(data)=c("TMB","Gene","Type")


yMax=3            
breakPoints=2      
data$Type=factor(data$Type, levels=c("Wild","Mutation"))
p=ggboxplot(data, x="Gene", y="TMB", color = "Type",
     ylab="", width=0.6, add = "none", xlab="",
     palette = c("blue","red"))+rotate_x_text(60)+scale_y_continuous(expand=c(0,0),breaks=c(seq(0,breakPoints,10),seq(breakPoints,yMax,30)))
split1 <- p + coord_cartesian(ylim = c(0,breakPoints))+
	labs(y='TMB')+theme(axis.title.y = element_text(hjust = 1, size = 14),legend.position='none',plot.title = element_text(hjust = 0.8))
split2 <- p + coord_cartesian(ylim = c(breakPoints, yMax))+
	theme(axis.text.x=element_blank(),axis.line.x=element_blank(),axis.ticks.x=element_blank(),legend.position='top',plot.title = element_text(hjust = -0.45, vjust=2.12))+
	stat_compare_means(aes(group=Type),label.y = yMax*0.9,symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "ns")),label = "p.signif")

g<-plot_grid(split2,split1,nrow=2,align = 'v',rel_heights = c(1,2))
ggsave("boxplot4.pdf",g,width=8,height=6)	



