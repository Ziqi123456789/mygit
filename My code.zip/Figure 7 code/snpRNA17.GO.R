install.packages("colorspace")
install.packages("stringi")
install.packages("ggplot2")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
BiocManager::install("DOSE")
BiocManager::install("clusterProfiler")
BiocManager::install("enrichplot")

library("clusterProfiler")
library("org.Hs.eg.db")
library("enrichplot")
library("ggplot2")

pvalueFilter=0.05                   
adjpFilter=0.05                     
showNum=20                          

setwd("D:\\sxzxw\\90snpRNA kidney\\17.GO")               
rt=read.table("id.txt",sep="\t",header=T,check.names=F)           
rt=rt[is.na(rt[,"entrezID"])==F,]                                 
gene=rt$entrezID
geneFC=rt$logFC
names(geneFC)=gene

colorSel="p.adjust"
if(adjpFilter>0.05){
	colorSel="pvalue"
}

for(i in c("BP","CC","MF")){
	kk=enrichGO(gene = gene,OrgDb = org.Hs.eg.db, pvalueCutoff =1, qvalueCutoff = 1, ont=i, readable =T)
	GO=as.data.frame(kk)
    GO=GO[(GO$pvalue<pvalueFilter & GO$p.adjust<adjpFilter),]
	write.table(GO,file=paste0(i,".txt"),sep="\t",quote=F,row.names = F)                 #���渻�����
	if(nrow(GO)<showNum){
		showNum=nrow(GO)
	}
	if(nrow(GO)!=0){
		pdf(file=paste0(i,".barplot.pdf"),width = 11,height = 12)
		bar=barplot(kk, drop = TRUE, showCategory =showNum,color = colorSel)
		print(bar)
		dev.off()
		
		pdf(file=paste0(i,".bubble.pdf"),width = 11,height = 12)
		bub=dotplot(kk,showCategory = showNum, orderBy = "GeneRatio", color = colorSel)
		print(bub)
		dev.off()
	}
}

