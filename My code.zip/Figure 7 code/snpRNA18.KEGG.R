#install.packages("colorspace")
#install.packages("stringi")
#install.packages("ggplot2")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("DOSE")
#BiocManager::install("clusterProfiler")
#BiocManager::install("enrichplot")


library("clusterProfiler")
library("org.Hs.eg.db")
library("enrichplot")
library("ggplot2")

pvalueFilter=0.05                
adjpFilter=0.05                  
showNum=20                  

setwd("D:\\sxzxw\\90snpRNA kidney\\18.KEGG")                
rt=read.table("id.txt",sep="\t",header=T,check.names=F)            
rt=rt[is.na(rt[,"entrezID"])==F,]                                 
gene=rt$entrezID
geneFC=rt$logFC
names(geneFC)=gene

colorSel="p.adjust"
if(adjpFilter>0.05){
	colorSel="pvalue"
}

kk <- enrichKEGG(gene = gene, organism = "hsa", pvalueCutoff =1, qvalueCutoff =1)   
KEGG=as.data.frame(kk)
KEGG$geneID=as.character(sapply(KEGG$geneID,function(x)paste(rt$id[match(strsplit(x,"/")[[1]],as.character(rt$entrezID))],collapse="/")))
KEGG=KEGG[(KEGG$pvalue<pvalueFilter & KEGG$p.adjust<adjpFilter),]
write.table(KEGG,file="KEGG.txt",sep="\t",quote=F,row.names = F)                    

if(nrow(KEGG)<showNum){
	showNum=nrow(KEGG)
}

pdf(file="barplot.pdf",width = 10,height = 7)
barplot(kk, drop = TRUE, showCategory = showNum, color = colorSel)
dev.off()

pdf(file="bubble.pdf",width = 10,height = 7)
dotplot(kk, showCategory = showNum, orderBy = "GeneRatio",color = colorSel)
dev.off()

