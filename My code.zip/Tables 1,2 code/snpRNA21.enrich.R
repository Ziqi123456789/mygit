#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("org.Hs.eg.db")
#BiocManager::install("clusterProfiler")

pvalueFilter=0.05                    
adjpFilter=0.05                      

setwd("D:\\sxzxw\\90snpRNA kidney\\21.subEnrich")           

library("org.Hs.eg.db")
library("clusterProfiler")                                      
rt=read.table("gene.txt",sep="\t",check.names=F,header=F)     

for(i in 1:nrow(rt)){
	genes=strsplit(as.character(rt[i,]),split = ", ")
	genes=unlist(genes)
	id=mget(genes, org.Hs.egSYMBOL2EG, ifnotfound=NA)           
	id=as.character(id)
	data=cbind(symbol=genes,entrezID=id)
	id=id[is.na(id)==F] 
	
	GG=enrichGO(gene = id,OrgDb = org.Hs.eg.db, pvalueCutoff =1, qvalueCutoff =1, ont="all", readable =T)
	GO=as.data.frame(GG)
	GO=GO[(GO$pvalue<pvalueFilter & GO$p.adjust<adjpFilter),]
	write.table(GO,file=paste0("subNet",i,".GO.txt"),sep="\t",quote=F,row.names = F)                 #���渻�����
	
	kk <- enrichKEGG(gene = id, organism = "hsa", pvalueCutoff =1, qvalueCutoff =1)   
	KEGG=as.data.frame(kk)
	KEGG$geneID=as.character(sapply(KEGG$geneID,function(x)paste(data[,"symbol"][match(strsplit(x,"/")[[1]],as.character(data[,"entrezID"]))],collapse="/")))
	KEGG=KEGG[(KEGG$pvalue<pvalueFilter & KEGG$p.adjust<adjpFilter),]
	write.table(KEGG,file=paste0("subNet",i,".KEGG.txt"),sep="\t",quote=F,row.names = F)                    
}

