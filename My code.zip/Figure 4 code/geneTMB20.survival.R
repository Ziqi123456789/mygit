#install.packages("survival")
install.packages("survminer")

library(survival)
library(survminer)

inputFile="mutTime.txt"        
col=c("red","blue")            
setwd("D:\\108geneTMB\\20.survival")                 
rt=read.table(inputFile,header=T,sep="\t",check.names=F,row.names=1)  
rt$futime=rt$futime/365        

outTab=data.frame()
for(gene in colnames(rt)[3:ncol(rt)]){
	diff=survdiff(Surv(futime, fustat) ~rt[,gene],data = rt)
	pValue=1-pchisq(diff$chisq,df=1)
	outVector=cbind(gene,pValue)
	outTab=rbind(outTab,outVector)
	if(pValue<0.001){
		pValue="p<0.001"
	}else{
		pValue=paste0("p=",sprintf("%.03f",pValue))
	}
	fit <- survfit(Surv(futime, fustat) ~ rt[,gene], data = rt)
	
	surPlot=ggsurvplot(fit, 
		data=rt,
		pval=pValue,
		pval.size=6,
		legend.labs=c("Mutation","Wild"),
		legend.title=gene,
		font.legend=12,
		xlab="Time(years)",
	    palette=col,
		break.time.by = 1,
		conf.int=T,
		fontsize=4.5,
		risk.table=TRUE,
		ylab="Overall survival",
		risk.table.title="",
		risk.table.height=.25)
	pdf(file=paste0(gene,".pdf"),onefile = FALSE,
		width = 6,         
		height =5)         
	print(surPlot)
	dev.off()
}

outTab=outTab[order(as.numeric(as.vector(outTab$pValue))),]
write.table(outTab,file="survival.result.xls",sep="\t",row.names=F,quote=F)

