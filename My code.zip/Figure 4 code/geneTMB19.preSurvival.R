mutFile="TCGA.mutMatrix.txt"         
cliFile="time.txt"                   
geneFile="intersectGenes.txt"        
setwd("D:\\108geneTMB\\19.preSurvival")     

data=read.table(mutFile,sep="\t",header=T,check.names=F,row.names=1)

gene=read.table(geneFile,header=F,sep="\t",check.names=F)
data=data[as.vector(gene[,1]),]

group=sapply(strsplit(colnames(data),"\\-"),"[",4)
group=sapply(strsplit(group,""),"[",1)
group=gsub("2","1",group)
data=data[,group==0]
colnames(data)=gsub("(.*?)\\-(.*?)\\-(.*?)\\-(.*?)\\-.*","\\1\\-\\2\\-\\3",colnames(data))
data=t(data)

cli=read.table(cliFile,sep="\t",check.names=F,header=T,row.names=1)

sameSample=intersect(row.names(data),row.names(cli))
data=data[sameSample,]
cli=cli[sameSample,]
out=cbind(cli,data)
out=cbind(id=row.names(out),out)
write.table(out,file="mutTime.txt",sep="\t",row.names=F,quote=F)


