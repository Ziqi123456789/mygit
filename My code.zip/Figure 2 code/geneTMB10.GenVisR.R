

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GenomeInfoDbData")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GenVisR")


setwd("D:\\108geneTMB\\10.TCGAwaterfall")

library(GenVisR)
rt=read.table("waterfallInput.txt",header=T,sep="\t",check.names=F,quote="")
pdf(file="waterfall.pdf",height=8,width=13)
waterfall(rt,rmvSilent = T,mainDropMut=F)
dev.off()



