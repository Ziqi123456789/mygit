#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

install.packages("beeswarm")
library(beeswarm)
library(limma)

setwd("D:\\sxzxw\\90snpRNA kidney\\12.scatter")         
inputFile="normalExp 1.txt"                                      
gene="CTLA4"                                                   
normalNum=514                                                 
tumorNum=25                                                    
yMin=0                                                        
yMax=10                                                       
ySeg=yMax*0.94

labels=c("Wild type","Mutation")
type=c(rep(1,normalNum),rep(2,tumorNum))
Type=c(rep("Normal",normalNum),rep("Tumor",tumorNum))
rt=read.table(inputFile,sep="\t",header=T,check.names=F)
rt=as.matrix(rt)
rownames(rt)=rt[,1]
exp=rt[,2:ncol(rt)]
dimnames=list(rownames(exp),colnames(exp))
data=matrix(as.numeric(as.matrix(exp)),nrow=nrow(exp),dimnames=dimnames)
data=avereps(data)
rt=rbind(expression=log2(data[gene,]+1),type=type)
rt=as.matrix(t(rt))

wilcoxTest=t.test(expression ~ type, data=rt)
wilcoxP=wilcoxTest$p.value
pvalue=signif(wilcoxP,4)
pval=0
if(pvalue<0.001){
     pval=signif(pvalue,4)
     pval=format(pval, scientific = TRUE)
}else{
     pval=round(pvalue,3)
}

pdfFile=paste(gene,".pdf",sep="")
pdf(file=pdfFile,width = 6,height = 4.5)
par(mar = c(5,6,3,3))
boxplot(expression ~ type, data = rt,names=labels,xlab=gene,
     ylab = paste(gene," expression (log2)",sep=""),
     cex.main=1.3, cex.lab=1.1, cex.axis=1.1,ylim=c(yMin,yMax),outline = FALSE)
beeswarm(expression ~ type, data = rt, col = c("blue","red"),lwd=0.1,
     pch = 16, add = TRUE, corral="wrap")
segments(1,ySeg, 2,ySeg);segments(1,ySeg, 1,ySeg*0.98);segments(2,ySeg, 2,ySeg*0.98)
text(1.5,ySeg*1.03,labels=paste("p=",pval,sep=""),cex=1.2)
dev.off()


